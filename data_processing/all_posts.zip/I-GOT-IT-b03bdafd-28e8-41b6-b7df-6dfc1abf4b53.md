# I GOT IT...

Date: Dec 20, 2018
Mood: Excited,Happy,Optimistic
Productivity: Fitness,Programming

I got the R today.... 

oshitoshitoshit .

Anyways, other news.... Badminton yesterday. think i;ve joined the league for next year !

slowly chipping away at Vue /tfl demos but taking way longer than i thought to make them. but considering i'm only working 1 hour or so at a time , this gonna take a while, hard to meet these montly deadlines.