# Almost end of the month and End of the Holiday  

Date: Oct 29, 2018
Mood: Happy,Sad
Productivity: Holiday

I have been slacking with these updates big time! I soppose it is to be expected whilst I'm on a holiday of a life time.

I cant beleive It's almost drawing to an end soon. Its been so fun and crazy at the same time. Probably over did it with the sunbathing and beaching yesterday as i've just felt tired all day! Was still a great day on a speedboat island hopping. Since I last logged, my sister got married. And what a perfect wedding it was , despite the heat. 

The bar has been set high! I  have no way to top this. I need to save a hell of a lot of money in the next coming months...

In the personal dev side of things, I'm not going to hit my targets again... I've been following the rabbit hole and its led me to vue.js. I need to understand how I got here...

1) exploring JS modules

2) running JS modules using systemJS and JSPM

3) bundling JS using Rollup and other things tools like webpack and Parcel

4) reading about how other frameworks intergrate their process to use webpack for bundling at production

5) vueJS - messing around with it. I makes it so easy to target dom elements without any fuss... its designed to be written in a modular way and has custom components

vue js as a framework seems to emcompass what I want in design pattern for a web application. Though for some reason i'm hesitant to go all in on it. why?

some reasons why...

1) its abstraction of the DOM and will deter me from learning how the DOM works at a deeper level

2) Hype around vueJS . will it stand the test of time.. hard to say. If I build my apps around it it could become the jquery of tomorrow and make it undesirable to work with.

3) There's a lot of concepts to learn and  I will need to sink some good amount of time into it to get the most out of it.

reasons 2 and 3  dont seem like legitimate reasons to not learn vue ... but 1 I need to keep that in mind at all times. I still need to learn to do things the hard way somewhere down the line. But the some of the hard work that vue does out-of the-box is just too good to not take up.  

I will learn from the concepts of vue... perhaps it will make it easier to pick up other frameworks likes react. But I need to understand the core principals of what vue is trying to achieve to really get value out of it use it as a stepping stone to become a better developer.

Time to update my training plan again to maximize my time.