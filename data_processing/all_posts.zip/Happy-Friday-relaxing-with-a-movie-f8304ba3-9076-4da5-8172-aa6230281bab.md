# Happy Friday, relaxing with a movie

Date: Jul 19, 2018
Mood: Content,Happy
Productivity: Leisure

Another week over . pent the evening relaxing with jenny and watching Life of pi. Great movie !

Did a little coding but only for like 15 mins