# Break through on a silly mistake

Date: Jan 11, 2019
Mood: Frustrated,Tired
Productivity: Programming

Worked out with the issue was last from yesterday. just a little missing character `method` rather than writing `methods` . So annoying

neeed to step away, feels counter intuitive but would have probalby helped me figure it out sooner.

been in door all day today wfh. its been nice. but probs not great for my mental health. probs is a good thing to get out the house every now and then.

feel lost at work. jsut dont give a shit. just want to learn vue all day till i master it .