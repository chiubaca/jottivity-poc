# Sweat It Out

Date: Aug 09, 2018
Mood: Energetic,Happy,Optimistic,Tired
Productivity: Fitness,Leisure

Good first day of sprinting today, actually wrote some working code with the help of Tony. Feeling optimistic we can actually deliver some value to the business. Gotta believe more in myself.

Tried out a cool new class at a place called Sweat It . Definitely a good work out thats for sure! balanced it out with a fat burger!