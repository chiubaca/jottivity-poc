# Shopping for flat stuff

Date: Jul 14, 2018
Mood: Content,Tired
Productivity: Life,Programming

A busy day of unsuccessfully trying to find stuff for the flat. Ended up spending a ton of money on food at Wing Yip . Found a great Vietnamese joint upstairs, forgot the name though... something like "An banana"..!? 

Come back home and successfully cooked pad thai for the first whilst making a massive mess in the kitchen.

Squeezed in some time to solve some basic logarithm  challenges in FCC. feeling knackered now!