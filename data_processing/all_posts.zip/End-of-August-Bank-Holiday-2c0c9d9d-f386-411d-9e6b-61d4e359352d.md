# End of August Bank Holiday :(

Date: Aug 27, 2018
Mood: Content,Happy
Productivity: Friends,Programming

Been slacking a bit with journal, need to stop.

The last weekend has really taken a hit to my routine and discipline. I can see how I become out unproductive quickly....

Over the last couple of days  and the bank holiday I have re-prioritised by personal goals and blogged about my latest goals :

[https://chiubaca.github.io/code/2018/08/23/august-update.html](https://chiubaca.github.io/code/2018/08/23/august-update.html) 

I've been going through the Dojo docs and everything seems to make so much more sense now. I feel almost a bit annoyed about why I couldn't grasp some of the concepts the first time , it might just be because there is so much to it?

My Dojo calculator app is coming along and I understand how to create and import my modules, I've also implemented the basic UI. I seem to lose interest once I have got the pattern down and it is just a case of repeating the functionality. Might be becasue i've done the "hard part". Interesting to note down my behaviours though. 

Had weekend overall catching up with a few different friends. I just wish I could spend my time with all over them all of the time!