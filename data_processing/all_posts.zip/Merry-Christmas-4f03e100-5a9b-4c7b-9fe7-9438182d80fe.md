# Merry Christmas

Date: Dec 25, 2018
Mood: Happy
Productivity: Family,Holiday,Life

its been the holidays, been playing with vue more and making progress with tfl demos... not on track with my cs50 courses though...

need to get back on it tomorrow after xmas is over.

general thoughts and feelings... cant wait for saturday. the next big chapter in my life.

Next year I WILL leave TfL. time to move on, all that waiting around last year, waiting for what? Need to find something i care about,  will other organisation be better? i dont know. need to keep an eye out and just talk to employers to see if what I can offer is good enough.

technology is the feild im going to stay in, web development is what i want to specialise in. GIS is my core skills. Can I combine this all together ?