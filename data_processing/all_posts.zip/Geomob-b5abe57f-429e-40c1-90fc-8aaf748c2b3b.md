# Geomob

Date: Sep 06, 2018
Mood: Content,Optimistic
Productivity: Friends,Work

Slow day at work. 

Geomob was interesting. Awkward seeing my old lecture, but kept it civil. 

Things to follow up on :

Zoomstack

Algolia geocoder