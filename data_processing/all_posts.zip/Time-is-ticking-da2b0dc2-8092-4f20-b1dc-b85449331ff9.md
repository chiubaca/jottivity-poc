# Time is ticking

Date: Nov 29, 2018
Mood: Annoyed,Excited,Tired
Productivity: Fitness,Leisure,Life,Programming

Combination of feelings over the last couple days

joined a new badminton club in welling with great people , but so tired after playing...

excited for operation D - but time is ticking and I'm running out of time now.....

Annoyed from Jenny being stroppy, but I have my space to do my own thing. Learning Vue and its really cool. some of the abstraction is a bit scary, but I see my self being productive with it!