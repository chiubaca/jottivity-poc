# More shopping and researching...

Date: Dec 02, 2018
Mood: Happy,Tired
Productivity: Family,Life

jennys gone shopping mad. but hey is xmas

emails enquiries sent... honing down on what I want now... fuuuucK this is getting real! interesting pang is gonna pop the question tooo. These things all seem to happen at once. 2019 will surely be interesting....

need to get on top my training plan. chipping away at vue... jobs seem to show react is whats hot at the moment... hmmm