# Completed Basic Algorithm Scripting

Date: Jul 17, 2018
Mood: Content,Tired
Productivity: Programming

Its another hot ass July day. 

Chilled day at work - spent much of evening cooking up a nice dinner.

Manged to completed the last two challenges in the FCC basic Algorithm Scripting module. Now on to objected oriented programming . I think this might be the third time I have learn OO style programming . I feel I understan the principles of it, but i still fail to use it in practice. Will be good to refresh my understanding of it all by going through the module.