# still stuck on vue exercise

Date: Jan 16, 2019
Mood: Frustrated
Productivity: Fitness,Programming

only a quick pomodoro spent on the vue exercise... still not much more progress.

not getting any value trying to work out what is going on and trying tofix it.

trying to push but still grasp the concepts of what is happening.... 

even if it the final product does not work. hopefully i will learn a bit