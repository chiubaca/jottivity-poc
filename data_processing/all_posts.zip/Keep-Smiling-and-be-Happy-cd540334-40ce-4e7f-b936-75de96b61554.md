# Keep Smiling and be Happy

Date: Nov 08, 2018
Mood: Motivated,Optimistic,Tired
Productivity: Programming

Another busy day at work , fixing shit which other people broke, was nervous but beleived in myslef that I could fix it and have made good progress. why do I doubt myself sometimes? I can do it.

spent the evening cooking which is form of therpy for me now .

complated my vue calculator. so simple once you know how. much more improvements to be made but time to move on to other parts of the vue framework