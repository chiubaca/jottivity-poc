# General Assembly

Date: Nov 13, 2018
Mood: Inspired,Motivated
Productivity: Self Development

Something a bit different this evening. A UI UX class at the GA.

Very good instructor with some amazingly useful and practical advice for designing new feature in apps.

will be back for more lessons if I get the chance.

Food for thought : could I get into UI UX as a career?