# Dojo Calculator all working !

Date: Aug 30, 2018
Mood: Content,Happy
Productivity: Leisure,Life,Programming

Demoing what  we have done for the two weeks to the buisness at work today. They seemed to be impressed. To be fair the senior dev did most of the heavy lifting regarding the coding... Need to be more involved in the coding but i cant seem to keep up with pace....

At home its was a busy evening cooking and driving around. Got home and have completed the the full functionality of the dojo calculator. Was much easier than expected, though using eval() seems to be a bit cheap.... always seems to be the way when i figure out a solution, once you know how, it always seem to easy...?

Anways downloaded dead cell to replace my addiction to fornite. poison for another poison? .....