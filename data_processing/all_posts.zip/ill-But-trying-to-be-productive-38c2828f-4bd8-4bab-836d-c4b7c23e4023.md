# ill But trying to be productive

Date: Dec 14, 2018
Mood: Motivated,Optimistic,Tired
Productivity: Programming,Self Development

Got ill from colleagues...

been a relatively chilled week at work. Still thinking that the commute is not good for my mental well-being. More motivated than ever to make a change to my life. stop living this rat race. Cant help but compare myself to others....

done some more goal planning for my year ahead. notion ftw again. might need to pay for a subscription. This is just too danm useful.