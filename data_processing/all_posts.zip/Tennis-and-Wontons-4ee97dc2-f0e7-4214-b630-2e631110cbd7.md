# Tennis and Wontons

Date: Sep 19, 2018
Mood: Happy,Tired
Productivity: Leisure

Thrashed nye at tennis again. perhaps i'm better than i thought or hes just shit? moaned and bitched a lot about things at work. dunno if this is normal. Doenst feel right. time to look for a new job perhaps?

Got back from tennis and made wontons which i made with dad over the weekend. Also danm delicious! Fuck im getting good at cooking. just chilled and watched youtube before sleeping. Feeling fucking knackered.