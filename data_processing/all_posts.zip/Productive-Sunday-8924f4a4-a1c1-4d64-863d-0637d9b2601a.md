# Productive Sunday

Date: Jul 15, 2018
Mood: Happy,Tired
Productivity: Fitness,Leisure,Life,Programming

Great Sunday

- Run at scadbury
- cooked roast pork
- saw family
- started reading through terms to get fence sorted for patio
- completed more challenges on FCC almost finished basic algorithms module