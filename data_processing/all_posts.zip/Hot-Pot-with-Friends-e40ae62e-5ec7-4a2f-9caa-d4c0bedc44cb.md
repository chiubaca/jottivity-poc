# Hot Pot with Friends

Date: Oct 13, 2018
Mood: Tired
Productivity: Fitness,Friends,Leisure,Programming

Finally a gym sesh.

also cooked and tried to do a bit of reading around js modules again, few journals seem to be point back to webpack.

feeling knackered, think last week is catching up with me. spent the rest of the evening out in london eating food with kalan and jarry.