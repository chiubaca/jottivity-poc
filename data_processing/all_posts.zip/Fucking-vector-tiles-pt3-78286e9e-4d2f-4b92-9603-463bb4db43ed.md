# Fucking vector tiles pt3

Date: Sep 09, 2018
Mood: Annoyed,Frustrated
Productivity: GIS,Leisure

More work on vector tiles via tileserver-gl. 

carried the work over to jennys Mum and looked after and played with her nephew and neice (so cute).

Still tinkering with the configs... getting closer to getting this working... but danm this is annoying.... spent all weekend on this and neglected my coding..... REALLY WANT TO GET THIS WORKING!!!

Also watched "Searching" great mystery movie btw!