# Vue Break Through

Date: Dec 17, 2018
Mood: Happy,Motivated
Productivity: Programming

Managed to get past the issue I was stuck on ! was just a simple error which I was able to overcome.

first tfl demo is almost complete!

Another annoying day at work . NEED TO QUIT , is what i keep telling myself. some front end dev jobs looks very appealing. Maybe i should just go for them....