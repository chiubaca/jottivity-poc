# Struggling

Date: Nov 06, 2018
Mood: Dissatisfied,Tired

Jet lag hitting me bad....

So tired at work still.. 

Early night sleep again and try to break out of this tomorrow