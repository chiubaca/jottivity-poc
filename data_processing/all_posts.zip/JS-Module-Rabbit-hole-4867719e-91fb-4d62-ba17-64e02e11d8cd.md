# JS Module Rabbit hole

Date: Oct 08, 2018
Mood: Content,Optimistic
Productivity: Leisure

Busy day at work. Lots of code reviews.

At home bot much coding per se , but lots of reading around js modules. Feels like ive gone down a rabbit hole...

Es6 modules has led me to 

Module loaders like

System js 

Browserify

Webpack.

Think i need to give them all a try..  Or do i ? 

I am particulary interested in webpack at the very least due to seeing it dev tools. 

Let see if i can get out to th other side in one peice.