# Rewflection on Yesterday  & Dinner with Jennys Family

Date: Dec 30, 2018
Mood: Happy,Tired
Productivity: Family,Life,Programming

Reflection on yesterday, it was truly magical.  dropped to one knee and seeing a crowd form around us. Some radom woman screaming " oh my god hes going to propose". The lighting changed and  there I was proposing to the love of my love. 

what a sureal outer body experience...Something I will never ever forget.

I barely slept last night. so tired and very weird nonsensical dream about coding?! and the day that just happened. 

spent the whole day cooking for jennys fam. Time to sleep soon. soo soo very tired. cant wait to celebrate with friends tomorrow , New years eve and engagement celebrations!