# Not enough sleep

Date: Jul 23, 2018
Mood: Annoyed,Frustrated,Tired
Productivity: Programming,Work

Crap night sleep last night. Too fucking hot! its a crazy heat wave at the moment and was 33 degrees today.

Dara at work is so negative sometimes and can be real drag... He single handedly makes me want to quit on days like today.

I need to keep my options open that for sure though. The pace at TfL is painstakingly slow, it seems people just dont care...

Lack of sleep has probably put in me slightly bad mood, also has to spend my evening implementing a change. The one good thing is that I completed the Objected Oriented Programming module on FCC. It all made sense too. Classes, the module pattern, even Closures are now starting to click. I need to make this stick somehow . I still struggle to think of a way to use OO programming in personally applications though. I just got to start using classes.