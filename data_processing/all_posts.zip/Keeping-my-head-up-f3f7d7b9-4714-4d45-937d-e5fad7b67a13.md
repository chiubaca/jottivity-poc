# Keeping my head up

Date: Nov 07, 2018
Mood: Motivated
Productivity: Programming

Trying to get back in to the swing of things. discovered the Joe Rogan Experience podcast which has been motivational. he talks about disciple and trying to do your best.

The work we put in is usually makes more of an impact than we realise. Need to remember this.

So with this mind set in place I was able to channel some of this energy into a stressful day at work.  things still seem to be going wrong , but i'll do my best to fix them.

The podcast hit close to home, they talked about dissatisfaction , depression and not getting enough sunlight.... all things I'm feeling. In someway i had similar thought around this time 2 and half years ago at esri.... need to keep an eye on what else is out there, but at the same time. I must salvage what I have.

was productive in the evening listening to more JRE whilst cooking and did a bit vue programming. need to finish this calc off and push on with learning the rest of vue. i'm going to ride this vue wave and see where it takes me. fuck it.