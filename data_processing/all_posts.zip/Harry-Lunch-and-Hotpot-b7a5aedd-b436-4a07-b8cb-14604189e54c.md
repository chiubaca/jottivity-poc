# Harry Lunch and Hotpot

Date: Jan 12, 2019
Mood: Happy
Productivity: Friends,Leisure

fun day at harry lunch and hot pot , holiday planning!