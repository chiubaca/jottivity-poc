# End of the month..

Date: Sep 30, 2018
Mood: Dissatisfied,Nervous,Tired
Productivity: Leisure,Life,Programming

At the end of another month. Some mixed feelings about this. 

how did this month fly by so quickly?

Did I hit my goals?

I suppose I should I use this as a opportunity to look back on this month. what was soppose to be calm month was still a busy one. BAU work seemed to get in the way of my development work. I wanted to do more learning around Dojo and WAB, but tbf , I have learnt loads about Dojo this month, but overall my coding activity has seen a slump - I've been tired recently, my fitness has also slipped. I think this all may have something to do work overall. 

I really should find a new job, but I guess I feel a different job would still be the same shit. coding seems to be my escape from GIS admin work, but at the same time oppurtunities at work could be a great step up for my career. either way I just want to get really good at web dev, and software development... but I dont feel like i'm there at all. Still so much to learn.

Time to formulate my next learning objectives...