# Last Day at Work  & Holiday Packing

Date: Oct 16, 2018
Mood: Energetic,Happy,Tired
Productivity: Work

Frantic last day, trying to tie up loose ends before my last day . had dinner in bimibab then straight home packing and holiday prep till midnight. hard to sqeeze in some programming in between all of this!

cant wait for a lie in tomorrow