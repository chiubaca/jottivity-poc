# Mum and Dad come to visit :) (:

Date: Sep 16, 2018
Mood: Energetic,Happy
Productivity: Family,Leisure,Programming

Mum and dad came to visit today. first time they have been to flat for quite some time. They seem impressed with what we have done to the flat.

I  cooked them chicken and then dad taught me how to make wontons and soup base! Another recipe learnt. Got to refine and perfect it . Took parents out for shopping around bluewater and dad kept falling asleep. he is so old ....

So nice to see my parent <3 feel content. Tidied up after they left and sqeezed a bit more programming. 

Been learning more about widgets work in Dojo... I kind of get it. the pre-built methods kind of confuse me though. It seem like magic how some of the framework works. I've managed to scaffold up a basic calculator widget though. its working exactly how I imagined it too. Perhaps I need to let go of trying to understand how every bit of it works and take the abstractions as they are... I suppose it's a finding that balance in between. 

You need understand just enough of the abstractions to make you productive. Then you go deeper into understanding it when things are getting hacky... It's a skill in itself to know when that is. but that must just come with experience... 

I'll get my calculator widget working then move on to web app builder.