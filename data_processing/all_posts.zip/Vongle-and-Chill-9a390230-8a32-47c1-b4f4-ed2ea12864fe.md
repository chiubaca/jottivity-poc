# Vongle and Chill

Date: Sep 18, 2018
Mood: Happy
Productivity: Leisure

USed my mums clams to make vongle for the first time after today. was fucking delicious. need write down the recipe. too tired to code today, just chilled and watch the body guard and played more dead cells