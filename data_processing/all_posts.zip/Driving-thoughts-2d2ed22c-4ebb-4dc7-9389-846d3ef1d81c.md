# Driving thoughts

Date: Sep 17, 2018
Mood: Content,Tired
Productivity: Family,Leisure,Programming

Dinner with Jenny and her mum and planned for thailand for a little bit then drove back to the flat.

Some driving thoughts about programming.

- Learning a framework doesnt mean I know how to solve problem.  it just means i've studied the documentation.
- Do i really need to learn another framework?
- A framework is like a swordsmith - a developer is like the swordsman. Do you find to find mastery in one? or have an appreciation in both?
- I want to learn how to build things. programming is just a means to that
- I want to make augmented reality things