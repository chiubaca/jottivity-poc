# Hangover Sunday

Date: Sep 23, 2018
Mood: Content,Happy,Tired
Productivity: Family,Leisure,Programming

up early, cant sleep after too many beers the night before.

Managed to get my calculator dojo widget working after much fraustrations. Should be on track to finish my dojo training once i've created a WAB widget. Dunno how I managed to this hungover. somehow did though...

so tired again, napped till six ruined my sleeping pattern. spent the rest of the evening chilling, driving back to sidcup. sleeping pattern a bit fucked