# Friday again!

Date: Oct 05, 2018
Mood: Tired
Productivity: Fitness,Leisure,Programming

Been slacking with my journal keeping this week. Been a busy week work wise . Sprint is in full action and i'm enjoying the work for the most part , cool to be actually be doing real coding at work , unit tests and developery stuff! 

Not been doing much extra curriculum coding though, aside from watching some videos about require JS. gonna try and get leafet working as a module.

been naughty and playing games all week, playing fortnite again... NOT GOOD. only gonna play when pang and harry are on.

feeling hung over.. need to be productive this week....