# Tennis and still lethargic

Date: Sep 26, 2018
Mood: Tired,Unmotivated
Productivity: Fitness,Leisure

Maybe coming down with something... everyone at work is ill... Learnt loads about javascript testing which is cool.

Played tennis again and thrashed nye again. need a better opponent.

so tired still, need an early night, probs no coding again, chilling out and watching more killing eve cos yolo