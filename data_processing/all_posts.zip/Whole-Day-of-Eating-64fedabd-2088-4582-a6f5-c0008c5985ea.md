# Whole Day of Eating!

Date: Jul 29, 2018
Mood: Content,Energetic,Happy
Productivity: Fitness,Leisure,Life,Programming

Productive day tidying up the flat ready for Natalie to visit us. Sqeezed in a quick sesh at the gym and got another PB on my squats.

Ended cooking and eating pretty much all day long and watching films. What a lazy Sunday! Will try to get a bit of coding done before the end of the day.