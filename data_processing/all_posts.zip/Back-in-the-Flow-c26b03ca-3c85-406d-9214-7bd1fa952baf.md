# Back in the Flow

Date: Aug 20, 2018
Mood: Happy,Tired
Productivity: Life,Programming

Back in the flow of things, got a few life admin things sorted out. 

Read up on stocks and shares, something I will carry on learning about... just contemplating weather i should be paying off my student loan or not.... I've crunched the numbers here:  

[Google Sheets - create and edit spreadsheets online, for free.](https://docs.google.com/spreadsheets/d/1-7spIva8ACTkPrjtak14tnqadiQBn44FT56n-DWazZM/edit#gid=0)

Struggled a lot on the final FCC algos challenge, felt like i'm getting nowhere with it... i've got 9 more days to before my personal deadline is up. Gotta push through.