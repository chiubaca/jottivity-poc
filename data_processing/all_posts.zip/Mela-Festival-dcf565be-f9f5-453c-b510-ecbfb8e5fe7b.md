# Mela Festival

Date: Jul 22, 2018
Mood: Content,Energetic,Happy,Optimistic
Productivity: Leisure

Mela Festival at Eastleigh and catch up with the YQ crew. Its been a weekend of catching up with old friends :)

Nice lil 30 quid for helping out and got treated to KFC and ice cream, Winning!

Mid day nap, then retrospectively adding in my journal entries since Friday. 

I have slacked with my coding! but been well worth it to catch up with friends after months!

It's so important to catch up with old friends. Feel like my mind-set has been normalised slightly and I feel re-energised again. There still a lot I need to get done before this year ends and I'm feeling optimistic!