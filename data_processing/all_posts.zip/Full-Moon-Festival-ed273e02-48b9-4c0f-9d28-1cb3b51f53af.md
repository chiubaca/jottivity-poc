# Full Moon Festival

Date: Sep 24, 2018
Mood: Tired
Productivity: Leisure

tired again... always tired... 

Need to address this. 

- addicted to youtube on the bus. need to stop, replace with podcast and look outside
- not sleeping early enough
- slacking with my gym routine again.

Got home and cooked a nice meal for full moon festival tonight... 9:45 already, need to sleep... no programming tonight... work is a bit shitty recently.. new job!?