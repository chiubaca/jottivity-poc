# Merry Post Christmas!

Date: Dec 28, 2018
Mood: Content,Happy,Motivated
Productivity: Fitness,Leisure,Programming

Been a great couple of days,  drinnking too much hanging out with friends and family

back at the flat and been good to my self , relaxing , running and learning more Vue.

need to better understand how component communication works, something to focus on.  CS50 progress has taken a hit, but feeling good about learning Vue. Will need to pivot next month and reassess where I'm at.

Big day tomorrow so excited