# Friday Me Time

Date: Aug 10, 2018
Mood: Content,Happy,Tired
Productivity: Leisure,Programming

Me time, Jennys out for her leaving do so dedicated this Friday to me. Cooked a nice pork chop dinner and watched Afro Samurai.

Smashed out three FCC challenges ahead for this weekend and played a bit of fornite