# Big meal for everyone

Date: Sep 29, 2018
Mood: Content
Productivity: Family,Leisure,Life,Programming

Productive morning , well needed haircut. brekkie at maccy Ds and quick shop ready for a big cooking sesh for jennys fam . installed new blinds and the flat is looking comfy asf.

completed a few more tutorials for esri WAB, the link between WAB and dojo has clicked a little bit, biggested revelation so far is that it is just javascript... beyond some of the magic, it is a very well thought out framework. Esri technology is always just leveraging these technologies and pile on a load of complexity I find. seperate blog on this to come...