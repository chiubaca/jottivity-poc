# Functional Programming Breakthrough

Date: Jul 27, 2018
Mood: Happy,Optimistic
Productivity: Leisure,Programming

Evening to my self tonight. Feel like i've made a breakthrough on the functional programming module on FCC . It's all making sense and feels like a great coding style.

Also chilled and played some games and started watching some Afro Samurai, all round great evening.