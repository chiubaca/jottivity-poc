# Mums Birthday Meal in London

Date: Aug 11, 2018
Mood: Happy,Tired
Productivity: Family,Leisure,Life

Today went by in a blink of an eye. Woke up early to get groceries and an nice full english at the Olive tree in Bromley. Proper Peng!

Then head home and did a little bit of life admin before heading out to meet my Mum , Dad and Crystal for my mums birthday. Treated her to an expensive meal at the Baltahazer, she seemed to really enjoy the meal which made it all worth it despite the price of the meal. holy moly it was expensive....

After heading home it was about 21:00 . spent another hour prepping food for our house warming party for tomorrow . Then before I knew it was midnight.... Knackeeeerddd.....zzzzzzz