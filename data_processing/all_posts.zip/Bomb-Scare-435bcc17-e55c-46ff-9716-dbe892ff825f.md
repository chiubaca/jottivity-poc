# Bomb Scare

Date: Oct 01, 2018
Mood: Content,Optimistic
Productivity: Fitness,Life

Bomb scare at work today. had to evac and leave early. Pretty nuts in hindsight, even though everyone was so blase about it.

Felt good to hit the gym today. Dinner round Jennys dad today which was nice and spent the evening writing up about last months development progress.

Feels much better and optimistic this month after reflecting and setting new coding goals for this month.