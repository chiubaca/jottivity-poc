# After Work Drinks

Date: Sep 28, 2018
Mood: Happy,Tired
Productivity: Leisure,Work

another end to the work week . finished it with drinks with colleagues at the bar. Interesting to mingle with everyone out of work. Nye poured drinks all over big boss. hilarious XD. I was observing how everyone seems to be in their own little cliques... things dont change out of school really. There are the still the cool kids. or at work its the considered to be those doing the most interesting and important things. I suppose I get a bit jelous when i feel like i'm not in those circles... Do I just have to work harder?

No coding this evening , waay to tired.....