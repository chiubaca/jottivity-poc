# Nice way to end a tiring week

Date: Sep 14, 2018
Mood: Happy,Tired
Productivity: Leisure,Programming

Picking up the pieces from last night. spent all day work helping out the shitty support desk.

Interesting meeting at work about GIS frameworks and setting up the lots. may have been asking stupid questions but YOLO. learning about how this org buys GIS software. seems its the blind leading the blind.

Learning about widgets and dijits whilst at work.. seems kind confusing but playing with some more examples, feel a bit demotivated learning about it, need to fight past it.

finished the day with some tasty food at mein tay with jennys mate. I suppose we all get along pretty well, finished the evening with a good round of dead cells and crashing out :)