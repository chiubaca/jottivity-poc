# Fucking vector tiles pt2

Date: Sep 08, 2018
Mood: Annoyed,Frustrated
Productivity: GIS

Chilled out at the flat and spent most of the day researching how to server out vector tiles and focused on working on tileserver-gl.

trying to figure out it all works and tweaking configs ect