# Fucking vector tiles pt4

Date: Sep 10, 2018
Mood: Frustrated,Optimistic
Productivity: Fitness,GIS

Back at work and still thinking about vector tiles.... pretty chilled at work and just getting ready for a release, should be ok but still get nervous.

Smashed out a quick workout and cooked dinner and helped Jenny organise her work with a new kanban board . hopefully it helps her.

bit more prgress with tileserver and zoomstack. got a bit of UK rendered but the rest of it is not working..,. WHY!?! logged a ticket the tileserger-gl github. hopefully they can shed some light on this...

Is this all a waste of time? though I think it could solve some very real issues at work. could help us move away from ArcGIS server and their crappy caches...

business idea: Consultancy to help organizations move out of vendor lock in via alternatives and open-source solutions.