# Demotivating colleagues

Date: Nov 20, 2018
Mood: Annoyed,Unmotivated
Productivity: Leisure,Programming

*Sigh*

need to leave TfL not good for my mental health there. Its not worth it. 

everyone looks tired. they probably are.

colleagues not engaged in the project, shutting idea down.

my training needs to carry on, but at the same time i should start looking at other jobs?! time to see what web-dev jobs there are out there.