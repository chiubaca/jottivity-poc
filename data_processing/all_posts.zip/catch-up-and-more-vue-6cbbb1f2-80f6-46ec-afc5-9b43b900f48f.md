# catch up and more vue

Date: Jan 17, 2019
Mood: Motivated,Tired
Productivity: Friends,Programming

catch up with jordan. always a bit weird , but nice i suppose. good he makes the effort i suppose. the link to esri uk is still a strange one.

more vue when coming back - trying to crack on. app is still a bit broken. but just trying to take away some core concepts and learning about design patterns.

learnt about slots today. seems to all make sense.

reflected on what i want to do again.... feeling of doubt  which i'm trying to shake off. 

Will all this work pay off?

i hope so.......