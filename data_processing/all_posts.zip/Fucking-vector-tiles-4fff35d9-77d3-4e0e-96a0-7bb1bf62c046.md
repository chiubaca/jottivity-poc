# Fucking vector tiles

Date: Sep 07, 2018
Mood: Annoyed,Optimistic
Productivity: Programming,Work

Tryinng to get os zoom stack mbtiles working offline... Spent all day at work on it... Tried tilestream and now moving on to tileserver.