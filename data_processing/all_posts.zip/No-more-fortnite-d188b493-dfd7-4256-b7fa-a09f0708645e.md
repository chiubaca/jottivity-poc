# No more fortnite

Date: Aug 29, 2018
Mood: Dissatisfied,Frustrated
Productivity: Leisure,Programming

too obsessed with fornite recently , got a bit of dojo calculator workingby make use of eval(). feel stupid for trying to over complicate how I was gonna build this calculator...