# Happy Sunday

Date: Nov 11, 2018
Mood: Happy,Motivated
Productivity: Life,Programming

Productive morning - brekkie at poppins. shopping at wilkos and Asda.

Bombed it back to sidcup and went shopping for laptops - gonna get a dell xps 13 i think!

Cooking cleaning ect conscious I havent been working out at all!! 

anyway , back on Vue tutorials learning about vue components and the Vue file . Cool stuff. 

Time to chill and watch a movie :)