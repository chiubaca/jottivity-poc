# Completed Javascript Algorithms And Data Structures

Date: Aug 22, 2018
Mood: Content,Dissatisfied,Tired
Productivity: Programming

Not much coding yesterday, but been a productive week back at work so far. Tony has been smashing through all the user stories in my absence.

He can implement things so quickly it's pretty impressive. Feel like I have a long way to go, need to be able to understand logic as quickly as he can... all amounting me to feeling a bit dissatisfied with myself again...

I finally completed the all the projects for Javascript Algorithms And Data Structures in FCC. Got stuck in the last one, and spent a really long time looking at the provided answer and stepping through to understand what was going on, feel like I cheated a bit but I need to push on with my training. Going to readjust my personal goals to focus a bit more on Dojo so my skills are a bit more up to scratch for upcoming development work. I will revisit FCC afterwards when I feel a bit more comfortable with the framework.

Time for a Blog.