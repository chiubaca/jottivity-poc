# Pre holiday shopping

Date: Oct 14, 2018
Mood: Content
Productivity: Family,Programming

shopping in bluewater and then dinner at jennys mum today. spent a bit too much money before holiday next week....

trying out a webpack  / jsmodule tutorial from this guy... [https://medium.com/@svinkle/getting-started-with-webpack-and-es6-modules-c465d053d988](https://medium.com/@svinkle/getting-started-with-webpack-and-es6-modules-c465d053d988)

Lets see how I go