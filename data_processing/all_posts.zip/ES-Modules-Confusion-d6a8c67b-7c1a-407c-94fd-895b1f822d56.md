# ES Modules Confusion

Date: Oct 12, 2018
Mood: Confused,Tired
Productivity: Programming

Being slacking with my logs. Was so hung over and tired yesterday from the beers and random coffee at the JN talk. Work was a struggle yesterday, we're a bit behind in out sprint, but still managed to be fairly productive before the end of the week. Wrapping up for my holiday soon!

Trying to get my head around loading ES modules today. Trying to use system JS but brain is a bit fried. reached out to twitter. hopefully get some replies. More hacking around tomorrow...

Been slacking on my fitness too... NOT GOOD, lets get back on it tomorrrow. Bit of fortnite now.. hehe