# Flat Shopping in Lakeside

Date: Jul 28, 2018
Mood: Content,Tired
Productivity: Life,Programming

Spent pretty much all day at Lakeside shopping for flat stuff and was soooo LONG! 

We finally found dining chairs which we liked and were not too expensive. Was a pretty productive day of shopping to be fair.

Managed to squeeze in a little bit of coding and completed two more functional programming questions before getting interrupted to fix some non-issue with jennys car.