# stuck on vue exercise

Date: Jan 15, 2019
Mood: Annoyed,Frustrated
Productivity: Programming

stuck  on another thing on exercise 3 of vue js web development projects. components just are not interactive...

spending too long debugging these issues and getting stuck for too long.. hmm do i quit?