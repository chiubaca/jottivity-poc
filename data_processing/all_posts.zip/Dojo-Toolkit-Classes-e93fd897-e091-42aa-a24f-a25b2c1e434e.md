# Dojo-Toolkit Classes

Date: Sep 12, 2018
Mood: Tired
Productivity: Leisure,Programming

Cooked and learnt a bit more about dojo classes