# Trying to Chill

Date: Nov 19, 2018
Mood: Content,Happy
Productivity: Fitness,Leisure,Programming

Jenny cooked today :)

Good balance of fitness , cooking and leisure.

bit of vue training  then chilled and watched daredevil , trying to chill with jenny more. hard to squeeze it in.