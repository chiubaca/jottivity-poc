# Better Results

Date: Aug 08, 2018
Mood: Content,Tired
Productivity: Fitness,Programming

Amazing what a good night sleep makes , still behind on my sleep a bit but much more productive today.

Good day at work and got loads done ready for my first ever sprint doing "real dev" work. exciting!

Quick gym sesh, cooked dinner and smashed out 3 FCC challenges. Winning.