# House Warming At our Flat

Date: Aug 31, 2018
Mood: Energetic,Happy,Tired
Productivity: Friends,Leisure

Amazinly busy day hosting friends at our flat for the first time.... Pad Thai was a success and it was so nice having friends over.

Made me think whats important to me. Time with Friends and Family is seems so much more valuable as I get older, something I should not take for granted anymore , so I'm creating a two new productivity tags for friends and family, without them, what is this all really for? I feel tired but mentally re-energised at the same time.