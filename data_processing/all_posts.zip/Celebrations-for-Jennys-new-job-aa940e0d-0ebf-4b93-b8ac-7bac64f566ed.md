# Celebrations for Jennys new job!

Date: Jul 13, 2018
Mood: Content,Energetic,Happy
Productivity: Leisure,Programming

Quiet day at work, out for meal to celebrate the fact she got a new job and still managed to squeeze a small bit of FCC.