# Interesting Couple of Days

Date: Nov 25, 2018
Mood: Excited
Productivity: Fitness,Life,Work

Secret project is in full swing. need to do more research though, but its hard to do it in the flat.

Budget is set i think I just need work on the design

joined a new badminton club

Work is kinda going well .

Not much time recently to focus on my programming training....