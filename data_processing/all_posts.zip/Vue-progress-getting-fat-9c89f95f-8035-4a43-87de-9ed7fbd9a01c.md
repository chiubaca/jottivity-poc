# Vue progress getting fat

Date: Jan 07, 2019
Mood: Motivated,Tired
Productivity: Programming

Tiredness again...

Work is rubbish. Not motivated.

Vue learning going well. Completed first exercise.

Need more sleep. Less stress more fitness