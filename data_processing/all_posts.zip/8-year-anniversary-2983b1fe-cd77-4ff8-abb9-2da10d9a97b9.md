# 8 year anniversary 

Date: Sep 20, 2018
Mood: Frustrated,Happy
Productivity: Leisure

Work is shitty at the moment, getting that feeling of incompetence again. Just want to be some sort of rock star programmer that can make anything happen.... stressful dealing with incidents too, maybe because i take it to heart? Makes me wanna quit this job.... need to take deep long look at why i'm staying at TfL....

Tried to switch off after work, 8 years with jenny today after all. Amazing amount of time. Had dinner at stick and sushi. Was good, but too salty.... Became overwhelmingly full and tired suddenly.. these early starts jenny is having is really taking its toll. I looked awful in the reflection. Just feeling so so tired....