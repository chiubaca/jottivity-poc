# Production Change

Date: Sep 13, 2018
Mood: Angry,Dissatisfied,Frustrated,Tired
Productivity: Fitness,Work

Productive morning : - Gym and signed up to GP and cooked a cottage pie.

Production change went tits up and hit loads of problems , but it went through OK. just annoying to hit so many issues.

very tired now