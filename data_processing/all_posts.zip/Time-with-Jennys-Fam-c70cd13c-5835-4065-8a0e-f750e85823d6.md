# Time with Jennys Fam

Date: Jan 13, 2019
Mood: Happy
Productivity: Family,Programming

spent all day with jennys fam and her bros kids. i do like playing with them. brings out my inner child :)

sqeezed in 25 mins of vue js training then chilled out and watch the star in your something...

emosh