# Saturday Coding and Chill

Date: Oct 06, 2018
Mood: Content,Satisfied
Productivity: Leisure,Programming

Spent all day learning about require JS and got it working with leaflet. Worked through most of the pluralsight tutorial too, its only useful at a high level, still can go much deeper in require JS. but satisfied i know how to use it in a project.

ready to start learning about common JS , then es6 modules....

felt good to spend all day focused on it, finished the day by watching ant man and the wasp then sleeeping. perfect sat.