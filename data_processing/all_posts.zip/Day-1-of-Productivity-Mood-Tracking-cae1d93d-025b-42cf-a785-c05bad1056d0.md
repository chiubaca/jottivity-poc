# Day 1 of Productivity/Mood Tracking

Date: Jul 05, 2018
Mood: Happy
Productivity: Fitness,Programming

Start of this journal keeping experiment, lets see how this goes.

## Why am I doing this?

Just a little thought experiment - also curious to see if there any trends with why I have negative thoughts.

I've also wanted to get my thoughts down on paper for some time , seems unhealthy to keep everything inside with nowhere to vent.