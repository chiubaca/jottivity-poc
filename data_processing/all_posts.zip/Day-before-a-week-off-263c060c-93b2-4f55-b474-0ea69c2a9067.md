# Day before a week off

Date: Aug 13, 2018
Mood: Tired
Productivity: Leisure,Programming

Last day before a week off. Busy last day. Feeling very tired

Bit of coding movibg straight on to the fcc challenges