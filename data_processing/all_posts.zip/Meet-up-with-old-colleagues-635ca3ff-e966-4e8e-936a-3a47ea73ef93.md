# Meet up with old colleagues

Date: Jul 24, 2018
Mood: Happy,Tired
Productivity: Leisure

Slow day at work again.

Nice to catch up with old colleagues. Always have mixed feeling of nostalgia and doubt for some reason. Good to see everyone is doing well. I forget how smart they all are. 

Totally shattered from not enough sleep though...