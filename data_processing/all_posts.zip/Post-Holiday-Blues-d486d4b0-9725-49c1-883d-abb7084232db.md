# Post Holiday Blues

Date: Nov 05, 2018
Mood: Tired,Unmotivated

What an amazing holiday it was...

The full force of reality has hit me hard today.

The jet lag doesnt help.

The weekend boozing from martins wedding was probably a bad idea too.

Trying to get back into the flow of things. Important stuff to do this month, need to buy that *thing*.

Need crack on with my Vue training, finish off my vue calc and the net ninja tutorials. Some things I want to master..

- vue components
- build a vue application with cli
- PWA
- finish learning about modern ECMAscript