# Skipped Badders for cooking and code

Date: Jul 30, 2018
Mood: Content,Tired
Productivity: Leisure,Programming

Big cooking sesh instead of badmibton. Really cba for some reason this evening. Need to gym tomorrow though.

Almost completed the functional programming module and am getting a lot of value from it! I want to learn faster somehow though .