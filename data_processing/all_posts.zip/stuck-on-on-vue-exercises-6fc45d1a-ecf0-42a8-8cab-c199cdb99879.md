# stuck on on vue exercises

Date: Jan 10, 2019
Mood: Annoyed,Tired
Productivity: Programming

felt like i was making good progress on the vue exercises.

props were making sense, but hit a blocker in ther exercises. not sure if its something silly i've overlooked.

went way over my 3 pomodoros... hard to step away from it. 

I will figure it out. i need to understand how the project is working at deeper level rather than following the steps blindly.