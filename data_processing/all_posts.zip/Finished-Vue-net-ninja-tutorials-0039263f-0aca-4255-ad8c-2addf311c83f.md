# Finished Vue net ninja tutorials

Date: Dec 08, 2018
Mood: Happy,Motivated,Optimistic
Productivity: Life,Programming,Self Development

Deposit is down - FUCK! shit is getting real

In other news finally finished the net ninja vue series , took a lot longer than expected but was great. need to put it into action.

First project - Time-To-Go app , an app thats lets u subscribe to train and bus times to let you know when you need to go .

I'm gonna build with VUE . 

MVP to subscribe to a certina train at a certain time. alarm rings when it is 15 mins due to leave.