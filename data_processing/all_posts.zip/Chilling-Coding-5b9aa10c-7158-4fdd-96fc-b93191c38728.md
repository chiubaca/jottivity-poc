# Chilling & Coding

Date: Aug 05, 2018
Mood: Content,Tired
Productivity: Leisure,Programming

Spent a good chunk of the day trying to do some challenges in the Intermediate Algorithm Scripting FCC module. struggling a bit, might be cos i've slacking the last couple of days, also alcohol last night probs didnt help...

I'm getting it through it slowly though, need to smash through these and get to the last challenges to get my certification. Need to make up for lost time from the last couple of days.