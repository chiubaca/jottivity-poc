# Lazy mode

Date: Sep 11, 2018
Mood: Tired,Unmotivated
Productivity: Leisure

Slow day at work... came back cooked and watch the new Mummy movie. whata load of crap. 

cba to do any coding , just feeling tired.