# HK / Thailand Update

Date: Oct 25, 2018
Mood: Happy,Motivated
Productivity: Holiday

Been a crazy couple of days!

Day 1 - Arrive in HK and straight to Tsuen Wan to see parents for a tasty thai dinner then back home and slept.

Day 2 - Morning shopping sesh and then back to Kenedy to get ready for Chans banquet and a long evening of kareoke

Day 3 - woke up at 1PM!  Met Jennys sum-sum then more shopping before going out with Jennys  mate Tun for some delish sushi

Day 4 - day exploring on a HK island , then to north HK to visit jennys couins

Day 5 - brekkie with America cousins and aunties then fly to Thailand. Got to thailand late so straight to bed

Day 6 - first morning in Thailand and its beautiful! had a random morning in Patong before going back to swim in our nearby beach whilst the sun sets

Day 7 - only 1 hour sleep cos something exploded outside, had deep thoughts about my career and future aspirations , what I wanna do and where I wanna go, blog to come to expand on these thoughts . went to a elephant santuary which was amazing :)

Day 8 - Island hoping  and dads Bday! pissed off jenny accidently... whoops. spent the evening with viet cousins. time to sleep......