# Why do I programme?

Date: Sep 04, 2018
Mood: Content,Optimistic
Productivity: Fitness,Programming

This video has really hit home...

[https://www.youtube.com/watch?v=EiKK04Ht8QI](https://www.youtube.com/watch?v=EiKK04Ht8QI)

"Dont be Programmer - Be a Problem Solver"

Why did I start learning to code? It was to make cool mapping stuff, and be able to use all the cool libraries and tools on github and all over the internet. I want to create data visualizations and make people go wow.

I think I've lost track of that somewhere along the lines... so focused on being the most competent at a technology for sake of learning a technology. I see other peoples work and think I could've have done that.... that feeling of annoyance and sadness.... it's because I didnt do that and I lost my way.

I'm only just realising this as I type these words...

I've learnt so much javascript over the last year and half, but what is it for? I need to make time to throw myself at some of those side projects that i've wanted to do for so long. 

My short term goals will pivot to allow for this. My Dojo traning continues. The framework is making more and more sense . I can make modules and classes and just need to get my head around dijits. This will set me on the right path for work and will continue hacking around with WAB - but thats work.

I'm going to recreate that transport music map. maybe something better! The time is now to make cool shit!