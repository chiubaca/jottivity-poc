# Portsmouth Catchup

Date: Sep 22, 2018
Mood: Content,Happy,Tired
Productivity: Family,Friends,Leisure,Programming

Back home in Portsmouth , tried coding for a bit but felt so lethargic so had a nap and ate loads of food my parents cooked. so nice :)

Dan came over and chilled and gave him instructions to look after the chickens whilst parents are away. 

Spent the rest of the evening chilling out round dans , drinking cocktails and playing with his dog before drinking too many pints down the denmead queen. Always good to chat about life, ambitions and goals with Dan, shame we dont do it more often these day....