# Catch up with Dan

Date: Jul 20, 2018
Mood: Content,Happy
Productivity: Fitness,Leisure

Took a random day off work. Chilled out and took it easy in the flat and sqeezed in a gym sesh before driving back down to Portsmouth.

Thought about a lot of things driving back down : -

- What it means to be young Asian professional
- Am I happy?
- Rings, proposals , weddings ...

Was great to catch up with Dan and pour out some of these thoughts that have been going through my mind.

Some actionable things: -

- Build something small for someone to improve their life
    - A quote machine to improve Jennys confidence?
    - magic mirror for mum?
- Mentoring
- INAP app

Dan has a great thing going on with his gardening business . Direct contact with his clients means he has very rewarding engagements and customers that genuinely appreciate his work. This all amounts to very satisfying work and all in all being a happy person.

***Is this what I'm striving for?***