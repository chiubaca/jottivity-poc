# Vue Productivity

Date: Dec 18, 2018
Mood: Optimistic,Tired
Productivity: Programming

work sucks atm, but feeling super productive working with vue atm.

need to crack on with the other demos, falling behind on my objective again!!