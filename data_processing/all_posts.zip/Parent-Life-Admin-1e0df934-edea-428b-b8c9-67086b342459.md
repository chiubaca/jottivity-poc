# Parent Life Admin

Date: Aug 01, 2018
Mood: Content
Productivity: Life

At Crystals place for dinner and spent the evening sorting admin stuff for dad. Had to be done. Watch more episides of Our Girl in the evening so no coding this evening...