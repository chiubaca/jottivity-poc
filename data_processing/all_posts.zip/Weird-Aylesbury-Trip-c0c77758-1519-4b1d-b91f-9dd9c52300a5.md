# Weird Aylesbury Trip

Date: Nov 16, 2018
Mood: Confused
Productivity: Friends

Decided to go Aylesbury for a surprise bday for Jonathan. Seemed like a good idea at the time , but instantly regretted as I got on the train.

I dont even like any of the those guys.  I like Jonathan and I get along with Jordan and Ben I supposed but feels so forced when I have a convo with any of the other guys there. What a waste of an evening . wish I spent it with Jenny.