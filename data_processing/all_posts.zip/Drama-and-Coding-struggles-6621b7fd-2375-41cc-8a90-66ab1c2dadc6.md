# Drama and Coding struggles

Date: Aug 07, 2018
Mood: Frustrated,Tired
Productivity: Fitness,Life,Programming

Not a good start to the day, my questions from the weekend were answered . Should I feel bad about everything. Yes. My actions have consequences.  I apologised to Martin for being a dick which has led me take a deep hard look at myself as person. Its all well and good that I develop my hard skills such as programming, but I need to also spend time with my friends and family too, becasue otherwise, what is this all for? Might need a tag for bonding. so i can see when I am spending quality time with other people.  For example I dont feel I really spent an quality time with Jenny this evening . I was focused and annoyed with with my in ability to get past the pig latin coding challenge on FCC. spent more than 2 hours getting no where....

Time is so precious and needs to be rationed like a scarce resource.

My heads a bit of mess from the weekend and lack of sleep. Need to sort my self out.