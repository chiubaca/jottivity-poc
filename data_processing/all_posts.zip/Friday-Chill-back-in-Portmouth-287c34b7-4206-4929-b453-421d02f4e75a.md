# Friday Chill - back in Portmouth

Date: Aug 03, 2018
Mood: Content,Tired
Productivity: Leisure

Drove back to portsmouth after work and getting ready for Goodwood tomorrow