# Too many things I want to do

Date: Dec 11, 2018
Mood: Nervous,Tired
Productivity: Fitness,Programming

feeling nervous for some reason. overwhelmed that I never gonna be good enough . questioning if really want to be a developer.

I do like coding. am i burning out?

need to write down everything I want to do and priorotise it into effort